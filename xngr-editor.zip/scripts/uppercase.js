var selected = exchanger.getSelection();
exchanger.replaceSelection(selected.toUpperCase());
